-- AFTERHOURS CUSTOM RANKS + ROOM EDITOR
-- Run this once in Supabase SQL Editor before using /editor.

create extension if not exists pgcrypto;

create table if not exists public.afterhours_roles (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  color text not null default '#ffffff',
  badge text not null default '🏷️',
  priority integer not null default 0,
  permissions jsonb not null default '[]'::jsonb,
  is_system boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.afterhours_rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text not null default '',
  visibility text not null default 'public' check (visibility in ('public','private')),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.afterhours_room_permissions (
  room_id uuid not null references public.afterhours_rooms(id) on delete cascade,
  role_name text not null,
  permission text not null,
  primary key (room_id, role_name, permission)
);

create index if not exists afterhours_roles_name_idx on public.afterhours_roles(name);
create index if not exists afterhours_rooms_name_idx on public.afterhours_rooms(name);

-- Seed the current built-in ranks. Existing rows are left untouched so
-- anything you customize in /editor survives re-running this script.
insert into public.afterhours_roles (name,color,badge,priority,permissions,is_system)
values
('Owner','#f5c542','👑',100,'["promote_users","demote_users","set_ranks","manage_ranks","create_rooms","delete_rooms","edit_any_room","manage_room_permissions","manage_staff","ban_users","unban_users","mute_users","unmute_users","kick_users","warn_users","restrict_users","delete_any_message","handle_serious_reports","manage_site_settings","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('Developer','#b887ff','🛠️',90,'["manage_site_settings","mute_users","kick_users","ban_users","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('Admin','#ff6878','🔴',80,'["manage_staff","set_ranks","create_rooms","delete_rooms","edit_any_room","manage_room_permissions","ban_users","unban_users","mute_users","unmute_users","kick_users","warn_users","restrict_users","delete_any_message","handle_serious_reports","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('Moderator','#62b0ff','🔵',60,'["delete_messages","mute_users","kick_users","warn_users","temporary_ban_users","handle_reports","manage_conversations","manage_rooms","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('Helper','#61db96','🟢',40,'["help_users","answer_questions","report_problems","warn_users","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('VIP','#f3df4e','⭐',20,'["vip_badge","vip_name_color","premium_profile_perks","create_premium_rooms","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('OG','#ff9d4d','🌟',10,'["og_badge","og_name_color","early_member_perks","chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true),
('Member','#b8b8c2','⚪',0,'["chat","manage_own_profile","upload_profile_picture","join_rooms","send_messages"]',true)
on conflict (name) do nothing;

insert into public.afterhours_rooms (name,description,visibility)
values
('General','Talk. Connect. Chill.','public'),
('Gaming','Talk about games.','public'),
('Music','Share music and discover new stuff.','public')
on conflict (name) do nothing;

alter table public.afterhours_roles enable row level security;
alter table public.afterhours_rooms enable row level security;
alter table public.afterhours_room_permissions enable row level security;

drop policy if exists "roles readable by authenticated" on public.afterhours_roles;
create policy "roles readable by authenticated" on public.afterhours_roles
for select to authenticated using (true);

drop policy if exists "rooms readable by authenticated" on public.afterhours_rooms;
create policy "rooms readable by authenticated" on public.afterhours_rooms
for select to authenticated using (visibility = 'public' or created_by = auth.uid());

drop policy if exists "room permissions readable by authenticated" on public.afterhours_room_permissions;
create policy "room permissions readable by authenticated" on public.afterhours_room_permissions
for select to authenticated using (true);

create or replace function public.afterhours_editor_can_manage()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  my_role text;
  allowed boolean;
begin
  if auth.uid() is null then return false; end if;
  if auth.uid() = 'e3b8dd5d-56cf-447e-95e6-4506a1c818ce'::uuid then return true; end if;
  select role into my_role from public.profiles where id = auth.uid();
  select exists(
    select 1 from public.afterhours_roles r
    where r.name = my_role and r.permissions ? 'manage_ranks'
  ) into allowed;
  return coalesce(allowed,false);
end;
$$;

create or replace function public.afterhours_editor_save_role(
  p_id uuid,
  p_name text,
  p_color text,
  p_badge text,
  p_priority integer,
  p_permissions jsonb
)
returns public.afterhours_roles
language plpgsql
security definer
set search_path = public
as $$
declare
  old_role public.afterhours_roles;
  result_role public.afterhours_roles;
  my_role text;
  my_priority integer;
begin
  if not public.afterhours_editor_can_manage() then
    raise exception 'You do not have permission to manage ranks.' using errcode = '42501';
  end if;
  select role into my_role from public.profiles where id = auth.uid();
  select priority into my_priority from public.afterhours_roles where name = my_role;

  if p_name is null or length(trim(p_name)) < 1 or length(trim(p_name)) > 32 then
    raise exception 'Rank name must be 1-32 characters.';
  end if;
  if p_priority is null or p_priority < 0 or p_priority > 99 then
    raise exception 'Rank priority must be between 0 and 99.';
  end if;
  if auth.uid() <> 'e3b8dd5d-56cf-447e-95e6-4506a1c818ce'::uuid and p_priority >= coalesce(my_priority,0) then
    raise exception 'You cannot create or edit a rank at or above your own priority.' using errcode = '42501';
  end if;

  if p_id is null then
    insert into public.afterhours_roles(name,color,badge,priority,permissions,is_system,created_by,updated_at)
    values(trim(p_name),coalesce(nullif(p_color,''),'#ffffff'),coalesce(nullif(p_badge,''),'🏷️'),p_priority,coalesce(p_permissions,'[]'::jsonb),false,auth.uid(),now())
    returning * into result_role;
  else
    select * into old_role from public.afterhours_roles where id=p_id;
    if not found then raise exception 'Rank not found.'; end if;
    if old_role.priority >= coalesce(my_priority,0) and auth.uid() <> 'e3b8dd5d-56cf-447e-95e6-4506a1c818ce'::uuid then
      raise exception 'You cannot edit a rank at or above your own priority.' using errcode = '42501';
    end if;
    update public.afterhours_roles
    set name=trim(p_name), color=coalesce(nullif(p_color,''),'#ffffff'), badge=coalesce(nullif(p_badge,''),'🏷️'), priority=p_priority, permissions=coalesce(p_permissions,'[]'::jsonb), updated_at=now()
    where id=p_id
    returning * into result_role;
    if old_role.name <> result_role.name then
      update public.profiles set role=result_role.name where role=old_role.name;
      update public.afterhours_room_permissions set role_name=result_role.name where role_name=old_role.name;
    end if;
  end if;
  return result_role;
end;
$$;

create or replace function public.afterhours_editor_delete_role(p_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare r public.afterhours_roles;
begin
  if not public.afterhours_editor_can_manage() then raise exception 'You do not have permission to manage ranks.' using errcode='42501'; end if;
  select * into r from public.afterhours_roles where id=p_id;
  if not found then return false; end if;
  if r.is_system then raise exception 'Built-in ranks cannot be deleted. Edit their permissions instead.'; end if;
  delete from public.afterhours_roles where id=p_id;
  update public.profiles set role='Member' where role=r.name;
  return true;
end;
$$;

create or replace function public.afterhours_editor_create_room(
  p_name text, p_description text, p_visibility text, p_allowed_roles text[], p_manage_roles text[]
)
returns public.afterhours_rooms
language plpgsql
security definer
set search_path = public
as $$
declare result_room public.afterhours_rooms; r text;
begin
  if not public.afterhours_editor_can_manage() then raise exception 'You do not have permission to manage rooms.' using errcode='42501'; end if;
  if p_name is null or length(trim(p_name)) < 1 or length(trim(p_name)) > 40 then raise exception 'Room name must be 1-40 characters.'; end if;
  if p_visibility not in ('public','private') then raise exception 'Invalid room visibility.'; end if;
  insert into public.afterhours_rooms(name,description,visibility,created_by,updated_at)
  values(trim(p_name),coalesce(p_description,''),p_visibility,auth.uid(),now())
  returning * into result_room;
  foreach r in array coalesce(p_allowed_roles,array['Member']::text[]) loop
    insert into public.afterhours_room_permissions(room_id,role_name,permission) values(result_room.id,r,'view') on conflict do nothing;
  end loop;
  foreach r in array coalesce(p_manage_roles,array['Owner']::text[]) loop
    insert into public.afterhours_room_permissions(room_id,role_name,permission) values(result_room.id,r,'manage') on conflict do nothing;
  end loop;
  return result_room;
end;
$$;

grant execute on function public.afterhours_editor_can_manage() to authenticated;
grant execute on function public.afterhours_editor_save_role(uuid,text,text,text,integer,jsonb) to authenticated;
grant execute on function public.afterhours_editor_delete_role(uuid) to authenticated;
grant execute on function public.afterhours_editor_create_room(text,text,text,text[],text[]) to authenticated;
