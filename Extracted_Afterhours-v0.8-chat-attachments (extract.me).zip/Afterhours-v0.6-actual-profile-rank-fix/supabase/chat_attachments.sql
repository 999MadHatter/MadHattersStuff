-- AFTERHOURS CHAT ATTACHMENTS
-- Run this once in Supabase SQL Editor.

insert into storage.buckets (id, name, public)
values ('chat-files', 'chat-files', false)
on conflict (id) do update set public = false;

-- Users can upload files into their own user-id folder.
drop policy if exists "Afterhours chat files upload own folder" on storage.objects;
create policy "Afterhours chat files upload own folder"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'chat-files'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Authenticated users can read chat attachments through signed URLs.
drop policy if exists "Afterhours chat files read" on storage.objects;
create policy "Afterhours chat files read"
on storage.objects
for select
to authenticated
using (bucket_id = 'chat-files');

-- Users can remove files they uploaded.
drop policy if exists "Afterhours chat files delete own" on storage.objects;
create policy "Afterhours chat files delete own"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'chat-files'
  and (storage.foldername(name))[1] = auth.uid()::text
);

notify pgrst, 'reload schema';
