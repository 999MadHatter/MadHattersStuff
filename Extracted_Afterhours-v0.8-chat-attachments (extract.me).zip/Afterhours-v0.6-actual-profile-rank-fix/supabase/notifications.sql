-- Afterhours Notifications v0.5
-- Run this in Supabase SQL Editor.

create table if not exists public.notifications (
    id uuid primary key default gen_random_uuid(),
    recipient_id uuid not null references auth.users(id) on delete cascade,
    actor_id uuid references auth.users(id) on delete set null,
    type text not null,
    message text not null,
    reference_id uuid,
    read boolean not null default false,
    created_at timestamptz not null default now()
);

create index if not exists notifications_recipient_created_idx
    on public.notifications (recipient_id, created_at desc);

alter table public.notifications enable row level security;

drop policy if exists "Users can read their notifications" on public.notifications;
create policy "Users can read their notifications"
    on public.notifications for select
    to authenticated
    using (recipient_id = auth.uid());

drop policy if exists "Users can mark their notifications read" on public.notifications;
create policy "Users can mark their notifications read"
    on public.notifications for update
    to authenticated
    using (recipient_id = auth.uid())
    with check (recipient_id = auth.uid());

-- Notifications are created by trusted database code, not by the browser.
create or replace function public.afterhours_notify_dm()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
    recipient uuid;
    actor_name text;
    conversation record;
begin
    select participant_one, participant_two
      into conversation
      from public.dm_conversations
     where id = new.conversation_id;

    if conversation.participant_one is null then
        return new;
    end if;

    if new.sender_id = conversation.participant_one then
        recipient := conversation.participant_two;
    else
        recipient := conversation.participant_one;
    end if;

    if recipient is null or recipient = new.sender_id then
        return new;
    end if;

    select coalesce(nullif(display_name, ''), username, 'Someone')
      into actor_name
      from public.profiles
     where id = new.sender_id;

    insert into public.notifications (recipient_id, actor_id, type, message, reference_id)
    values (
        recipient,
        new.sender_id,
        'dm',
        actor_name || ' messaged you!',
        new.conversation_id
    );

    return new;
end;
$$;

drop trigger if exists afterhours_dm_notification on public.dm_messages;
create trigger afterhours_dm_notification
after insert on public.dm_messages
for each row execute function public.afterhours_notify_dm();

-- Enable realtime updates for the notifications table.
do $$
begin
    alter publication supabase_realtime add table public.notifications;
exception
    when duplicate_object then null;
end $$;
