import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  try {
    const { username, password } = await req.json();
    const cleanUsername = String(username ?? "").trim().replace(/^@/, "");

    if (!cleanUsername || !password) {
      return new Response(
        JSON.stringify({ error: "Username and password are required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } },
    );

    // Usernames are stored in auth.user_metadata during registration.
    // Paginate so this keeps working beyond the first 1,000 users.
    let page = 1;
    const perPage = 1000;
    let email: string | null = null;

    while (!email) {
      const { data, error } = await admin.auth.admin.listUsers({
        page,
        perPage,
      });

      if (error) throw error;

      const match = data.users.find((user) => {
        const stored = String(user.user_metadata?.username ?? "").trim();
        return stored.toLowerCase() === cleanUsername.toLowerCase();
      });

      if (match?.email) {
        email = match.email;
        break;
      }

      if (data.users.length < perPage) break;
      page += 1;
    }

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Invalid username or password." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Use the public client for the actual password authentication.
    const authClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } },
    );

    const { data: authData, error: authError } =
      await authClient.auth.signInWithPassword({
        email,
        password,
      });

    if (authError || !authData.session) {
      return new Response(
        JSON.stringify({ error: "Invalid username or password." }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ session: authData.session }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("login-by-username error:", error);

    return new Response(
      JSON.stringify({ error: "Unable to log in right now." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
